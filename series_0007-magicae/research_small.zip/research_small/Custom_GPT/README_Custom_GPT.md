Set the custom instructiions.

Enable Code interpretor.

Add the following files to Knowledge:

LIA_BOOTSTRAP_TEMPORAL_LOVE_V0003.json

Finnegans_wake.txt
